import logging

global_level = logging.WARNING
modlist_default = False
description_default = False
